-- CREAZIONE E ATTIVAZIONE DEL DATABASE: ToysGroup

CREATE DATABASE ToysGroup;
USE ToysGroup;

-- CREAZIONE DEI DATASET: Products, Sales, Category, Region e Country

CREATE TABLE Category (
    CategoryId INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
    Nome VARCHAR(50) NOT NULL, 
    Caratteristiche VARCHAR(200)
);

CREATE TABLE Products (
    ProductId INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
    Nome VARCHAR(50) NOT NULL, 
    CategoryId INT NOT NULL, 
    Caratteristiche VARCHAR(200),
    FOREIGN KEY (CategoryId) REFERENCES Category(CategoryId)
);

CREATE TABLE Region (
    RegionId INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
    Nome VARCHAR(50) NOT NULL 
);

CREATE TABLE Sales (
    SalesId INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
    ProductId INT NOT NULL, 
    RegionId INT NOT NULL, 
    Quantità INT NOT NULL, 
    DataDiVendita DATE NOT NULL, 
    Prezzo DECIMAL(13,2) NOT NULL,
    FOREIGN KEY(ProductId) REFERENCES Products(ProductId),
    FOREIGN KEY(RegionId) REFERENCES Region(RegionId)
);

CREATE TABLE Country (
    CountryId INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
    Nome VARCHAR(50) NOT NULL, 
    RegionId INT NOT NULL,
    FOREIGN KEY (RegionId) REFERENCES Region(RegionId)
);

-- INSERIMENTO DEI CAMPI

-- Category (7 valori)
INSERT INTO Category (Nome, Caratteristiche)
VALUES
    ("Giochi da tavolo", "Giochi che si svolgono su un tavolo con una plancia, pedine, carte e altri componenti"),
    ("Giochi di carte", "Giochi che si basano su un mazzo di carte, che possono essere utilizzate per giocare in vari modi, come associare coppie, costruire combinazioni o bluffare."),
    ("Giochi di abilità", "Giochi che richiedono destrezza, coordinazione e abilità manuali per essere vinti"),
    ("Giochi di costruzione", "Giochi che permettono di costruire modelli, edifici o altri oggetti utilizzando dei componenti"),
    ("Giochi di simulazione", "Giochi che ricreano situazioni o eventi reali, come la crescita di creature fantastiche o la gestione di una città"),
    ("Giochi di intrattenimento", "Giochi che servono principalmente a divertire e a trascorrere del tempo libero in modo spensierato"),
    ("Videogiochi", "Giochi che si svolgono su un dispositivo elettronico, come una console o un computer")
;    

-- Region (4 valori)
INSERT INTO Region (Nome)
VALUES
    ("Nord Europa"),
    ("Sud Europa"),
    ("Est Europa"),
    ("Ovest Europa")
;

-- Products (20 valori)
INSERT INTO Products (Nome, CategoryId, Caratteristiche)
VALUES
    ("Labirinto", 1, "Gioco di abilità per raggiungere il tesoro percorrendo un labirinto di tessere mobili"),
    ("Forza 4", 1, "Gioco di strategia con palline colorate da far cadere in una griglia"),
    ("Memory", 2, "Gioco di memoria per associare coppie di carte uguali"),
    ("Domino", 3, "Gioco di tessere con numeri o immagini da abbinare"),
    ("Yo-yo", 3, "Giocattolo da abilità per far salire e scendere un disco su una cordicella"),
    ("LEGO City", 4, "Set Lego con ambientazioni e personaggi urbani"),
    ("Meccano", 4, "Set di costruzioni con ingranaggi e motori per creare modelli realistici"),
    ("Monopoly", 1, "Gioco di compravendita di proprietà immobiliari"),
    ("Unstable Unicorns", 2, "Gioco di carte strategico con unicorni magici"),
    ("Dobble", 2, "Gioco di carte di abilità visiva per tutta la famiglia"),
    ("Hatchimals", 5, "Uova magiche che si schiudono e rivelano creature fantastiche"),
    ("Nerf", 6, "Fucili giocattolo che sparano dardi di schiuma"),
    ("Slime", 6, "Pasta modellabile viscida e colorata"),
    ("Carcassonne", 1, "Gioco di posa di tessere per creare un paesaggio medievale"),
    ("Magic: the Gathering", 2, "Gioco di carte collezionabili con un'ambientazione fantasy"),
    ("Yu-Gi-Oh!", 2, "Gioco di carte collezionabili basato su un anime e manga"),
    ("Dungeons & Dragons", 1, "Gioco di ruolo fantasy con dadi e miniature"),
    ("Pathfinder", 1, "Gioco di ruolo fantasy simile a Dungeons & Dragons"),
    ("Call of Cthulhu", 1, "Gioco di ruolo horror basato sulle opere di H.P. Lovecraft"),
    ("Nintendo Switch", 7, "Console di videogiochi portatile con una vasta gamma di giochi")
;

-- Sales (40 valori)
INSERT INTO Sales (ProductId, RegionId, Quantità, DataDiVendita, Prezzo)
VALUES
    (4, 1, 3457, '2022-11-14', 15.99),
    (12, 3, 87923, '2022-11-15', 29.99),
    (17, 2, 12345, '2022-11-16', 10.00),
    (20, 4, 56789, '2022-11-17', 349.99),
    (7, 1, 98765, '2022-11-18', 49.99),
    (1, 2, 23456, '2022-11-19', 24.99),
    (9, 4, 78901, '2022-11-20', 89.99),
    (14, 1, 10000, '2023-11-21', 14.99),
    (19, 3, 90000, '2023-11-22', 59.99),
    (3, 2, 45678, '2023-11-23', 39.99),
    (6, 4, 67890, '2023-11-24', 69.99),
    (11, 1, 20000, '2023-11-25', 19.99),
    (16, 3, 80000, '2023-11-26', 79.99),
    (5, 2, 30000, '2023-11-27', 49.99),
    (10, 4, 70000, '2021-11-28', 99.99),
    (2, 1, 1000, '2021-11-29', 9.99),
    (15, 3, 100000, '2021-11-30', 99.99),
    (8, 2, 50000, '2021-12-01', 69.99),
    (13, 4, 25000, '2020-12-02', 34.99),
    (18, 1, 75000, '2020-12-03', 84.99),
    (4, 1, 5457, '2020-11-14', 15.99),
    (12, 3, 77923, '2020-11-15', 29.99),
    (17, 2, 32345, '2021-11-16', 10.00),
    (20, 4, 46789, '2023-11-17', 349.99),
    (7, 1, 78765, '2023-11-18', 49.99),
    (1, 2, 13456, '2021-11-19', 24.99),
    (9, 4, 98901, '2021-11-20', 89.99),
    (14, 1, 12000, '2020-11-21', 14.99),
    (19, 3, 60000, '2020-11-22', 59.99),
    (3, 2, 65678, '2022-11-23', 39.99),
    (6, 4, 87890, '2022-11-24', 69.99),
    (11, 1, 25000, '2021-11-25', 19.99),
    (16, 3, 70000, '2021-11-26', 79.99),
    (5, 2, 20000, '2021-11-27', 49.99),
    (10, 4, 80000, '2022-11-28', 99.99),
    (2, 1, 2000, '2022-11-29', 9.99),
    (15, 3, 150000, '2023-11-30', 99.99),
    (8, 2, 70000, '2023-12-01', 69.99),
    (13, 4, 65000, '2022-12-02', 34.99),
    (18, 1, 95000, '2022-12-03', 84.99)
;

-- Country (29 valori)
INSERT INTO Country (Nome, RegionId)
VALUES
    -- Nord Europa
    ("Danimarca", 1),
    ("Finlandia", 1),
    ("Islanda", 1),
    ("Norvegia", 1),
    ("Svezia", 1),
    -- Sud Europa
    ("Cipro", 2),
    ("Grecia", 2),
    ("Italia", 2),
    ("Malta", 2),
    ("Portogallo", 2),
    ("Spagna", 2),
    -- Est Europa
    ("Bulgaria", 3),
    ("Estonia", 3),
    ("Lettonia", 3),
    ("Lituania", 3),
    ("Polonia", 3),
    ("Repubblica Ceca", 3),
    ("Romania", 3),
    ("Slovacchia", 3),
    ("Ungheria", 3),
    -- Ovest Europa
    ("Austria", 4),
    ("Belgio", 4),
    ("Francia", 4),
    ("Germania", 4),
    ("Irlanda", 4),
    ("Lussemburgo", 4),
    ("Paesi Bassi", 4),
    ("Regno Unito", 4),
    ("Svizzera", 4)
;

-- QUERY

  -- 1. Verificare che i campi definiti come PK siano univoci. 

SELECT COUNT(CategoryId)
FROM Category
GROUP BY CategoryId
HAVING COUNT(CategoryId) > 1;

SELECT COUNT(CountryId)
FROM Country
GROUP BY CountryId
HAVING COUNT(CountryId) > 1;

SELECT COUNT(ProductId)
FROM Products
GROUP BY ProductId
HAVING COUNT(ProductId) > 1;

SELECT COUNT(RegionId)
FROM Region
GROUP BY RegionId
HAVING COUNT(RegionId) > 1;

SELECT COUNT(SalesId)
FROM Sales
GROUP BY SalesId
HAVING COUNT(SalesId) > 1;

  
  -- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT 
	Products.Nome AS Gioco, 
    SUM(Sales.Quantità * Sales.Prezzo) AS FatturatoTot, 
    YEAR(Sales.DataDiVendita) AS Anno
FROM Sales
JOIN Products ON Products.ProductId = Sales.ProductId
GROUP BY Products.Nome, YEAR(Sales.DataDiVendita);
  
  -- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
  
  SELECT 
    YEAR(Sales.DataDiVendita) AS Anno,
    Country.Nome AS Nazione,
    SUM(Sales.Quantità * Sales.Prezzo) AS FatturatoTotale
FROM Sales
JOIN Country ON Country.RegionId = Sales.RegionId
GROUP BY Year(Sales.DataDiVendita), Country.Nome
ORDER BY Anno, FatturatoTotale DESC;
  
  -- 4. Qual è la categoria di articoli maggiormente richiesta dal mercato? 
  
  SELECT 
	Category.Nome AS Gioco,
    SUM(Sales.Quantità*Sales.Prezzo) AS FatturatoTotale
  FROM Sales
  JOIN Products ON Products.ProductId = Sales.ProductId
  JOIN Category ON Category.CategoryId = Products.CategoryId
  GROUP BY Category.Nome
  ORDER BY FatturatoTotale DESC
  LIMIT 1;
  
  
  -- 5. Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
  
SELECT Nome
FROM Products
JOIN Sales ON Sales.ProductId = Products.ProductId
WHERE Sales.ProductId = 0;

		-- oppure 
 
SELECT Nome
FROM Products
WHERE ProductId NOT IN (
	SELECT DISTINCT ProductId 
    FROM Sales
    );
  
  
  -- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente). 
  
SELECT 
	Products.Nome As Gioco, 
    MAX(Sales.DataDiVendita) AS UltimaDataDiVendita
FROM Sales
JOIN Products ON Products.ProductId = Sales.ProductId 
GROUP BY Products.Nome
ORDER BY UltimaDataDiVendita DESC;
  
  
  /* BONUS: Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
  il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni 
  dalla data vendita o meno (>180 -> True, <= 180 -> False)
  */

SELECT 
    Sales.SalesId AS CodiceDocumento,
    Sales.DataDiVendita,
    Products.Nome AS Gioco,
    Category.Nome AS Categoria,
    Country.Nome AS Nazione,
    Region.Nome AS Regione,
    (DATEDIFF(CURRENT_DATE, Sales.DataDiVendita) > 180) AS "Trascorsi 180 giorni T/F"
FROM Category
JOIN Products ON Products.CategoryId = Category.CategoryId
JOIN Sales ON Sales.ProductId = Products.ProductId
JOIN Region ON Region.RegionId = Sales.RegionId
JOIN Country ON Country.RegionId = Region.RegionId;
